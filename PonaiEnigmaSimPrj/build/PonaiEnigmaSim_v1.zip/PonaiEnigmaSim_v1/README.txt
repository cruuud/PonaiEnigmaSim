----------------
Ponai Enigma Sim
----------------
  
  This application was created by someone with a passion for cryptography that can still be grasped by the common
  human mind.
  
  All Enigma information necessary to create this application was retrieved from the following sources and I want to
  thank them all for helping me out:
  
  http://www.cryptomuseum.com/ (thanks to Paul Reuvers for answering my questions)
  Daniel Palloks -  Helped me to fix my Uhr implementation bug! :-)
     His awesome Javascript emulator can be found here: https://people.physik.hu-berlin.de/~palloks/js/enigma/index_en.html
  David Hamer - Helping me out with questions regarding the stepping mechanism of the rotors
  
  You can contact me at ponai@ziggo.nl for any questions/remarks/bug etc.  
  Be aware that I tried my best to emulate everything as precise as I could, based on the information I could find,
  but this application will definitely contain bugs and you will come across situations where a message deciphered by this
  emulator could not be deciphered by some other emulator and vice versa.
  I gave this application to the general public, so anyone can fiddle around with it. You may copy/paste/use anything you
  find in this application, better yet: you can do anything you want with it.
  I just hope that you will like it.
  If you want to use anything from this application for commercial purposes, I will be last one to stop you, but I will not like you.
 
.Ponai, 2015-02-05

KVMXU KJFVB EXQUP KHKUO C